// src/supabase.js
import { createClient } from '@supabase/supabase-js';

// Replace with your Supabase URL and public anon key
const supabase = createClient(
  'https://miwzckhugymzpyotdoxx.supabase.co',  // Your Supabase URL
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1pd3pja2h1Z3ltenB5b3Rkb3h4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDM4Nzc0MTIsImV4cCI6MjA1OTQ1MzQxMn0.7Dk1PiEpH-VcZtfAF3Td2BEI8NbdK8jPhvZNzItw4bQ'  // Your Supabase anon key
);

export default supabase;

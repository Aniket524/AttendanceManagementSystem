import React, { useState, useEffect } from 'react';
import supabase from './supabase'; // Your Supabase client setup
import { useNavigate } from 'react-router-dom';
import './TeacherDashboard.css';  // Import a CSS file for styling

const TeacherDashboard = () => {
  const [students, setStudents] = useState([]);
  const [attendanceData, setAttendanceData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]); // Default to today's date
  const teacher = JSON.parse(localStorage.getItem('user'));
  const navigate = useNavigate();

  useEffect(() => {
    const fetchData = async () => {
      if (!teacher) {
        navigate('/login'); // Redirect if no teacher logged in
        return;
      }

      const teacherId = teacher.id;

      // Fetch all students associated with this teacher
      const { data: students, error: studentsError } = await supabase
        .from('students')
        .select('*')
        .eq('teacher_id', teacherId);

      if (studentsError) {
        console.error(studentsError);
        return;
      }

      setStudents(students);

      // Fetch attendance data for all students of this teacher on the selected date
      const { data: attendance, error: attendanceError } = await supabase
        .from('attendance')
        .select('*')
        .in('student_id', students.map(student => student.id))
        .eq('date', selectedDate); // Filter by selected date

      if (attendanceError) {
        console.error(attendanceError);
        return;
      }

      setAttendanceData(attendance);
      setLoading(false);  // Set loading to false after data is fetched
    };

    fetchData();
  }, [teacher, navigate, selectedDate]);

  // Handle marking attendance for students
  const handleMarkAttendance = async (studentId, status) => {
    const { error } = await supabase
      .from('attendance')
      .upsert([{ student_id: studentId, date: selectedDate, status }]); // Upsert (Insert or Update)

    if (error) {
      console.error(error);
      alert('Error marking attendance');
    } else {
      alert('Attendance marked successfully');
      // Refresh the attendance data for this teacher
      setAttendanceData(prevData => [
        ...prevData.filter(item => item.student_id !== studentId || item.date !== selectedDate),
        { student_id: studentId, date: selectedDate, status },
      ]);
    }
  };

  // Logout handler
  const handleLogout = () => {
    localStorage.removeItem('user'); // Remove user data from localStorage
    navigate('/login'); // Redirect to login page
  };

  return (
    <div className="teacher-dashboard">
      <header className="dashboard-header">
        <h2>Teacher Dashboard</h2>
        {loading && <p className="loading-text">Loading...</p>}
        <button className="logout-button" onClick={handleLogout}>Logout</button>
      </header>

      {!loading && (
        <>
          <section className="attendance-section">
            <h3>Student Attendance</h3>
            
            {/* Date picker */}
            <div className="date-picker-wrapper">
              <label>Select Date: </label>
              <input
                type="date"
                value={selectedDate}
                max={new Date().toISOString().split('T')[0]} // Prevent future dates
                onChange={(e) => setSelectedDate(e.target.value)} // Update selected date
              />
            </div>

            <div className="attendance-table-wrapper">
              <table className="attendance-table">
                <thead>
                  <tr>
                    <th>Student Name</th>
                    <th>Roll Number</th>
                    <th>Attendance</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {students.map(student => {
                    const attendanceForStudent = attendanceData.find(
                      (att) => att.student_id === student.id && att.date === selectedDate
                    );
                    return (
                      <tr key={student.id}>
                        <td>{student.name}</td>
                        <td>{student.roll_no}</td>
                        <td>
                          {attendanceForStudent ? (
                            attendanceForStudent.status === 'present' ? 'Present' : 'Absent'
                          ) : (
                            <span className="not-marked">Not marked yet</span>
                          )}
                        </td>
                        <td>
                          <button 
                            className="mark-button present" 
                            onClick={() => handleMarkAttendance(student.id, 'present')}
                          >
                            Mark Present
                          </button>
                          <button 
                            className="mark-button absent" 
                            onClick={() => handleMarkAttendance(student.id, 'absent')}
                          >
                            Mark Absent
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </section>
        </>
      )}
    </div>
  );
};

export default TeacherDashboard;

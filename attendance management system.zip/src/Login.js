import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import supabase from './supabase';
import './styles.css'; // Importing the styles

const Login = () => {
  const [id, setId] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('student');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();

    // Check if the user is a student or teacher based on the selected role
    if (role === 'student') {
      const { data: student, error: studentError } = await supabase
        .from('students')
        .select('*')
        .eq('roll_no', id)
        .eq('password', password)
        .single();

      if (student && !studentError) {
        localStorage.setItem('user', JSON.stringify({ id: student.id, role: 'student' }));
        navigate('/student-dashboard');
        return;
      }
    } else if (role === 'teacher') {
      const { data: teacher, error: teacherError } = await supabase
        .from('teachers')
        .select('*')
        .eq('id', id)
        .eq('password', password)
        .single();

      if (teacher && !teacherError) {
        localStorage.setItem('user', JSON.stringify({ id: teacher.id, role: 'teacher' }));
        navigate('/teacher-dashboard');
        return;
      }
    }

    setError('Invalid credentials. Please try again.');
  };

  return (
    <div className="form-container">
      <h2>Login</h2>
      <form onSubmit={handleLogin}>
        <input
          type="text"
          value={id}
          onChange={(e) => setId(e.target.value)}
          placeholder="Roll No/ID"
          required
        />
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Password"
          required
        />
        <div>
          <label>
            <input
              type="radio"
              value="student"
              checked={role === 'student'}
              onChange={() => setRole('student')}
            />
            Student
          </label>
          <label>
            <input
              type="radio"
              value="teacher"
              checked={role === 'teacher'}
              onChange={() => setRole('teacher')}
            />
            Teacher
          </label>
        </div>
        <button type="submit">Login</button>
      </form>
      {error && <p>{error}</p>}
      <div>
        <p>Don't have an account? <a href="/register">Register here</a></p>
      </div>
    </div>
  );
};

export default Login;

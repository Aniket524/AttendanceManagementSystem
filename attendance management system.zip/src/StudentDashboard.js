import React, { useState, useEffect } from 'react';
import supabase from './supabase'; // Your Supabase client setup
import './StudentDashboard.css';  // Import a CSS file for styling

const StudentDashboard = () => {
  const [attendance, setAttendance] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]); // Default to today's date
  const student = JSON.parse(localStorage.getItem('user'));

  useEffect(() => {
    const fetchAttendance = async () => {
      if (!student) {
        window.location.href = '/login'; // Redirect to login if no student is logged in
        return;
      }

      const studentId = student.id;

      // Fetch attendance data for the selected date
      const { data: attendanceData, error } = await supabase
        .from('attendance')
        .select('*')
        .eq('student_id', studentId)
        .eq('date', selectedDate); // Fetch attendance for the selected date

      if (error) {
        console.error(error);
      } else {
        setAttendance(attendanceData);
      }

      setLoading(false);
    };

    fetchAttendance();
  }, [student, selectedDate]);

  return (
    <div className="student-dashboard">
      <header className="dashboard-header">
        <h2>Student Dashboard</h2>
        {loading && <p className="loading-text">Loading...</p>}
      </header>

      {!loading && (
        <>
          <section className="attendance-section">
            <h3>Attendance Records</h3>

            {/* Date picker */}
            <div className="date-picker-wrapper">
              <label>Select Date: </label>
              <input
                type="date"
                value={selectedDate}
                max={new Date().toISOString().split('T')[0]} // Prevent future dates
                onChange={(e) => setSelectedDate(e.target.value)} // Update selected date
              />
            </div>

            <div className="attendance-table-wrapper">
              <table className="attendance-table">
                <thead>
                  <tr>
                    <th>Date</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {attendance.length > 0 ? (
                    attendance.map((record) => (
                      <tr key={record.id}>
                        <td>{record.date}</td>
                        <td>{record.status === 'present' ? 'Present' : 'Absent'}</td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan="2">No attendance records for this date</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </section>
        </>
      )}
    </div>
  );
};

export default StudentDashboard;

import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import supabase from './supabase';
import './styles.css';

const Register = () => {
  const [id, setId] = useState('');
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('student');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleRegister = async (e) => {
    e.preventDefault();

    const { data: existingStudent } = await supabase
      .from('students')
      .select('*')
      .eq('id', id)
      .single();

    const { data: existingTeacher } = await supabase
      .from('teachers')
      .select('*')
      .eq('id', id)
      .single();

    if (existingStudent || existingTeacher) {
      setError('ID already exists. Please choose another one.');
      return;
    }

    if (role === 'student') {
      const { error } = await supabase.from('students').insert([{ id, name, roll_no: id, password }]);
      if (error) {
        setError(error.message);
        return;
      }
      navigate('/student-dashboard');
    } else {
      const { error } = await supabase.from('teachers').insert([{ id, name, password }]);
      if (error) {
        setError(error.message);
        return;
      }
      navigate('/teacher-dashboard');
    }
  };

  return (
    <div className="form-container">
      <h2>Register</h2>
      <form onSubmit={handleRegister}>
        <input
          type="text"
          value={id}
          onChange={(e) => setId(e.target.value)}
          placeholder="ID"
          required
        />
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Name"
          required
        />
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Password"
          required
        />
        <select value={role} onChange={(e) => setRole(e.target.value)} required>
          <option value="student">Student</option>
          <option value="teacher">Teacher</option>
        </select>
        <button type="submit">Register</button>
      </form>
      {error && <p>{error}</p>}
      <div>
        <p>Already have an account? <a href="/login">Login here</a></p>
      </div>
    </div>
  );
};

export default Register;
